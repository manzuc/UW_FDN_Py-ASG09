#------------------------------------------#
# Title: Processing Classes
# Desc: A Module for processing Classes
# Change Log: (Who, When, What)
# DBiesinger, 2030-Jan-01, Created File
# DBiesinger, 2030-Jan-02, Extended functionality to add tracks
# CManzuk, 2022-03-27, completed assignment 9
#------------------------------------------#

if __name__ == '__main__':
    raise Exception('This file is not meant to ran by itself')

import DataClasses as DC


class DataProcessor:
    """Processing the data in the application"""


    @staticmethod
    def add_CD(CDInfo, table):          # Done (assumed)
        """function to add CD info in CDinfo to the inventory table.

        Args:
            CDInfo (tuple): Holds information (ID, CD Title, CD Artist) to be added to inventory.
            table (list of dict): 2D data structure (list of dicts) that holds the data during runtime.

        Returns:
            None.
        """

        cdId, title, artist = CDInfo            # variable assignment from arg tuple

        try:
            cdId = int(cdId)
        except:
            raise Exception('ID must be an Integer!')
 
        row = DC.CD(cdId, title, artist)
        table.append(row)


    @staticmethod
    def select_cd(table: list, cd_idx: int) -> DC.CD:        # Testing
        """selects a CD object out of table that has the ID cd_idx

        Args:
            table (list): Inventory list of CD objects.
            cd_idxSel (int): id of CD object to return

        Raises:
            Exception: If id is not in list.

        Returns:
            row (DC.CD): CD object that matches cd_idxSel
        """

        # TODO add code as required
        
        try:
            cd_idx = int(cd_idx)
        except:
            raise Exception('ID must be an Integer!')
         
        for cdObj in table:                                     #difficulties with this block
            if cdObj.cd_id == cd_idx: 
                print("CurrentCD:\t",cdObj)                     # calls __str__              
                return cdObj

        raise Exception('PC.select_cd - CD index not found in list')
