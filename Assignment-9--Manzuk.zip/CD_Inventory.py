#------------------------------------------#
# Title: CD_Inventory.py
# Desc: The CD Inventory App main Module
# Change Log: (Who, When, What)
# DBiesinger, 2030-Jan-01, Created File
# DBiesinger, 2030-Jan-02, Extended functionality to add tracks
# CManzuk, 2022-03-27, completed assignment 9
#------------------------------------------#

import ProcessingClasses as PC
import IOClasses as IO
import DataClasses as DC

lstFileNames = ['AlbumInventory.txt', 'TrackInventory.txt']
lstOfCDObjects = IO.FileIO.load_inventory(lstFileNames)
print ("\n\tloaded existing data in: \n\t", lstFileNames[0], "&", lstFileNames[1], "\n\n")

while True:
    IO.ScreenIO.print_menu()
    strChoice = IO.ScreenIO.menu_choice()

    if strChoice == 'x':
        break

    if strChoice == 'l':                                                # DONE
        print('WARNING: If you continue, all unsaved data will be lost and the Inventory re-loaded from file.')
        strYesNo = input('type \'y\' to continue and reload from file. otherwise reload will be canceled')

        if strYesNo.lower() == 'y':
            print('reloading...')
            lstOfCDObjects = IO.FileIO.load_inventory(lstFileNames)
            IO.ScreenIO.show_inventory(lstOfCDObjects)
        else:
            input('canceling... Inventory data NOT reloaded. Press [ENTER] to continue to the menu.')
            IO.ScreenIO.show_inventory(lstOfCDObjects)
        continue  # start loop back at top.

    elif strChoice == 'd':                                              # DONE
        IO.ScreenIO.show_inventory(lstOfCDObjects)
        continue  # start loop back at top.

    elif strChoice == 'a':                                              # DONE
        tplCdInfo = IO.ScreenIO.get_CD_info()               # reads input values into a tuple
        PC.DataProcessor.add_CD(tplCdInfo, lstOfCDObjects)
        IO.ScreenIO.show_inventory(lstOfCDObjects)
        continue  # start loop back at top.

    elif strChoice == 'c':                                              # DONE
        IO.ScreenIO.show_inventory(lstOfCDObjects)
        cd_idxSel = input('Select the CD / Album index: ')
        cdObj = PC.DataProcessor.select_cd(lstOfCDObjects, cd_idxSel)
        
        # TODO add code to handle tracks on an individual CD
        while True:
            print()
            IO.ScreenIO.print_CD_subMenu()
            strChoice = IO.ScreenIO.Submenu_CD_choice()       
  
            if strChoice == 'x':
                print("Returning to main menu")
                break
            
            elif strChoice == 'a':      # Add track                     # DONE
                tplTrkInfo = IO.ScreenIO.get_track_info()            # reads input values into a tuple
                print("\n\tDebug - ", tplTrkInfo,"\n")
                objNewTrk = DC.Track(tplTrkInfo[0],tplTrkInfo[1],tplTrkInfo[2])
                
                # DC.CD.add_track(cdObj, objNewTrk)
                cdObj.add_track(objNewTrk)
                print("debug - created")
                IO.ScreenIO.show_tracks(cdObj)
                continue

            elif strChoice == 'd':      # Display cd/Album tracks       # Done
                IO.ScreenIO.show_tracks(cdObj)
                continue
            
            elif strChoice == 'r':      # Remove track                  # DONE
                IO.ScreenIO.show_tracks(cdObj)
                trk_idx = input('Select the Track index: ')
                cdObj.rmv_track(trk_idx)
                IO.ScreenIO.show_tracks(cdObj)
                continue
      

    elif strChoice == 's':                                              # DONE
        IO.ScreenIO.show_inventory(lstOfCDObjects)
    
        strYesNo = input('Type \'y\' to save this inventory to file: ').strip().lower()

        if strYesNo == 'y':
            IO.FileIO.save_inventory(lstFileNames, lstOfCDObjects)
        else:
            input('The inventory was NOT saved to file. Press [ENTER] to return to the menu.\n')
        continue  # start loop back at top.

    else:
        print('Main - General Error')