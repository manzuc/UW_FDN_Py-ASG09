#------------------------------------------#
# Title: IO Classes
# Desc: A Module for IO Classes
# Change Log: (Who, When, What)
# DBiesinger, 2030-Jan-01, Created File
# DBiesinger, 2030-Jan-02, Extended functionality to add tracks
# CManzuk, 2022-03-27, completed assignment 9
#------------------------------------------#

if __name__ == '__main__':
    raise Exception('This file is not meant to run by itself')

import DataClasses as DC
import ProcessingClasses as PC

class FileIO:
    """Processes data to and from file:

    properties:

    methods:
        save_inventory(file_name, lst_Inventory): -> None
        load_inventory(file_name): -> (a list of CD objects)
    """


    @staticmethod
    def save_inventory(file_name: list, lst_Inventory: list) -> None:     # DONE
        """

        Args:
            file_name (list): list of file names [CD Inventory, Track Inventory] that hold the data.
            lst_Inventory (list): list of CD objects.

        Returns:
            None.
        """

    # DONE-TODO modify method to accept a list of file names.
        file_name_CD = file_name[0]
        file_name_Trk = file_name[1]
        
        print("\n\tSaving...\n")
       
        try:
            with open(file_name_CD, 'w') as file:            # DONE   #wipes existing file at this point
                for cdObj in lst_Inventory:
                    file.write(cdObj.get_recordCD()  )       #problem - fixed, modules weren't all on same rev

            print("\n\tAlbum list saved...\n")

    # TODO add code to save track data to file
            with open(file_name_Trk, 'w') as file:     
                for cdObj in lst_Inventory:
                    lstTracks = cdObj.cd_tracks             # cd_tracks is nested list of objects
                    for trk in lstTracks:
                        if trk is not None:
                            record = '{},{}'.format(cdObj.cd_id, trk.get_recordTrk()) 
                            file.write(record)
 
            print("\n\tTracks saved...\n")

        except Exception as e:
            print('\n\tIO.save_inventory - There was a general error!', e, e.__doc__, type(e), sep='\n')


    @staticmethod
    def load_inventory(file_name: list) -> list:    # DONE
        """

        Args:
            file_name (list): list of file names [CD Inventory, Track Inventory] that hold the data.
            data[n]: line elements read from csv file  

        Returns:
            list: list of CD objects.
        """


    # DONE-TODO modify method to accept a list of file names
        file_name_CD = file_name[0]
        file_name_Trk = file_name[1]
        
        lst_Inventory = []
        data=[]
        
        print("\n\tLoading...\n")

        try:
            with open(file_name_CD, 'r') as file:
                for line in file:
                    data = line.strip().split(',')
                    row = DC.CD(data[0], data[1], data[2]) 
                    lst_Inventory.append(row)                   # adds 'row' to end of lst_Inventory as object
       
            print("\n\tLoaded album list...\n")

      # DONE-TODO add code to load track data
            with open(file_name_Trk, 'r') as file:
                for line in file:
                    data = line.strip().split(',')
                    cdAlbum = PC.DataProcessor.select_cd(lst_Inventory, int(data[0]))  #identifies object in lst_Inventory

                    track = DC.Track(int(data[1]), data[2], data[3])  # creates new instance of 'Track' class
                    cdAlbum.add_track(track)    
                        # Adds instance of 'track' as Object in track list within obj identified by lst_Inventory element 'int(data[0])'  
 
            print("\n\tLoaded trk lists...\n")
                  
        except FileNotFoundError:
             print(file_name_CD, file_name_Trk, "Either or both files don't currently exist")
        except Exception as e:
            print('IO.load_inventory - There was a general error!', e, e.__doc__, type(e), sep='\n')

        return lst_Inventory

#=====================================================================

class ScreenIO:
    """Handling Input / Output"""


    @staticmethod
    def print_menu():               # Done
        """Displays a menu of choices to the user

        Args:
            None.

        Returns:
            None.
        """

        print("""\tMain Menu\n\n
		[l] load Inventory from file\n
		[d] Display Current Inventory\n
		[a] Add CD / Album\n
		[c] Choose CD / Album (CD Sub-menu)\n
		[s] Save Inventory to file\n
		[x] exit\n""")


    @staticmethod
    def menu_choice():              # Done
        """Gets user input for menu selection

        Args:
            None.

        Returns:
            choice (string): a lower case sting of the users input out of the choices l, a, d, c, s or x
        """

        choice = ' '

        while choice not in ['l', 'a', 'd', 'c', 's', 'x']:
            choice = input('Which operation would you like to perform? [l, a, d, c, s or x]: ').lower().strip()
        print()  # Add extra space for layout

        return choice


    @staticmethod
    def show_inventory(table):      # DONE
        """Displays current inventory table

        Args:
            table (list of dict): 2D data structure (list of dicts) that holds the data during runtime.

        Returns:
            None.
        """

        print('======= The Current Inventory: =======')
        print('ID\tCD Title (by: Artist)\n')
        for row in table:
            print(row)
        print('======================================')


    @staticmethod
    def get_CD_info():              # DONE
        """function to request CD information from User to add CD to inventory

        Returns:
            cdId (string): Holds the ID of the CD dataset.
            cdTitle (string): Holds the title of the CD.
            cdArtist (string): Holds the artist of the CD.
        """

        cdId = input('Enter ID: ').strip()
        cdTitle = input('What is the CD\'s title? ').strip()
        cdArtist = input('What is the Artist\'s name? ').strip()

        return cdId, cdTitle, cdArtist

                                        # ------------------------

    @staticmethod
    def print_CD_subMenu():            # testing
        """Displays a sub menu of choices for CD / Album to the user

        Args:
            None.

        Returns:
            None.
        """

        print("""\n\tCD Sub Menu\n\n
              [a] Add track\n
              [d] Display cd/Album tracks\n
              [r] Remove track\n
              [x] exit to Main Menu\n""")


    @staticmethod
    def Submenu_CD_choice():           # testing 
        """Gets user input for CD sub menu selection

        Args:
            None.

        Returns:
            choice (string): a lower case sting of the users input out of the choices a, d, r or x
        """

        choice = ' '

        while choice not in ['a', 'd', 'r', 'x']:
            choice = input('Which operation would you like to perform? [a, d, r or x]: ').lower().strip()
        print()  # Add extra space for layout

        return choice


    @staticmethod
    def show_tracks(cd):
        """Displays the Tracks on a CD / Album

        Args:
            cd (CD): CD object.

        Returns:
            None.
        """

        print('====== Current CD / Album: ======')
        print(cd)
        print('=============Tracks==============')
        print(cd.get_tracks())
        print('=================================')


    @staticmethod
    def get_track_info():
        """function to request Track information from User to add Track to CD / Album

        Returns:
            trkId (string): Holds the ID of the Track dataset.
            trkTitle (string): Holds the title of the Track.
            trkLength (string): Holds the length (time) of the Track.
        """

        trkId = input('Enter Position on CD / Album: ').strip()
        trkTitle = input('What is the Track\'s title? ').strip()
        trkLength = input('What is the Track\'s length? ').strip()
        return trkId, trkTitle, trkLength

